﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkAndEnergy_Part2_2DMotion
{
    class Program
    {
        static void Main(string[] args)
        {
            Motion motionLab = new Motion();
            motionLab.Start();
        }
    }
}
