﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkAndEnergyLabPart1
{
    /// <summary>
    /// @Author: Andrew Seba
    /// @Description: Marble in a bowl option
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //Instantiate the class
            MarbleLab lab1 = new MarbleLab();
            //start the sim
            lab1.Start();
        }


    }
}
